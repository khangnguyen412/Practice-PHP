<div class="sidebar pe-4 pb-3">
    <nav class="navbar bg-secondary navbar-dark">
        <a href="index.html" class="navbar-brand mx-4 mb-3">
            <h3 class="text-warning">
                <img src="../img/img/logo/LOGO-HOP-DEN.jpg" height="40" width="40" alt="">
                Ding Dong
            </h3>
        </a>
        <div class="navbar-nav w-100">
            <a href="../userview/index.php" class="nav-item nav-link text-warning">Trang Chủ</a>
            <a href="../dashboardcontroler/controler.php?action=showproduct" class="nav-item nav-link text-warning">Danh Mục</a>
            <a href="../dashboardcontroler/controler.php?action=showadmin" class="nav-item nav-link text-warning">Quản Trị Viên</a>
            <a href="../dashboardcontroler/controler.php?action=showuser" class="nav-item nav-link text-warning">Khách Hàng</a>
        </div>
    </nav>
</div>