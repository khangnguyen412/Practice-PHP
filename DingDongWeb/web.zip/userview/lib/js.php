 <!-- Javascript -->
 <script src="../assets/js/vendor/jquery-2.2.4.min.js"></script>
<script src="../assets/js/vendor/bootstrap-4.1.3.min.js"></script>
<script src="../assets/js/vendor/wow.min.js"></script>
<script src="../assets/js/vendor/owl-carousel.min.js"></script>
<script src="../assets/js/vendor/jquery.datetimepicker.full.min.js"></script>
<script src="../assets/js/vendor/jquery.nice-select.min.js"></script>
<script src="../assets/js/main.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>